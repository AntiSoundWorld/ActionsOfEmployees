import { invoke } from '@forge/bridge';
import React from 'react';

function Search(props){

    async function onSubmit(){

        let searchName = document.getElementById('searchEmployee');
        invoke("searchName", searchName)
        props.setSearchName(searchName);

    }

    return(
        <form>
            <input id="searchEmployee" label="Search Employee" name="name" />
            <button onClick={onSubmit} >Search</button>
        </form>
    )
}

export default Search;