import getInfo from '../GetInfo/getInfo';
import { getDates } from '../GetInfo/Tools/tools';
import React, { useState } from 'react';

function RangeDates(props){

    const[dates] = useState(getDates());

    const onSubmitRange = async (formData) => {

        props.setMacket(await getInfo(formData, props.basicToken));
    }

    return (
    <form onClick={onSubmitRange}>
        <input type='date' name="start" label="Start Date" defaultValue={dates.start}/>
        <input type='date' name="end" label="End Date" defaultValue={dates.end}/>
    </ form>);
}

export default RangeDates;