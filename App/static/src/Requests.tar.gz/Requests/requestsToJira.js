import { requestJira } from "@forge/bridge";

export async function requestsToJira() {

    let createmeta = await getCreatemeta(); // createmeta.projects

    const jiraResponses = {

        users: await getAllUsers(createmeta),

        comments: await Promise.all(createmeta.projects.map(project => {
            return getDatasComments(project.key);
        }))
    }

    // await getSprint();
    return jiraResponses
}

export async function getAllUsers(createmeta){

    return await Promise.all(createmeta.projects.map(project => {

        return getUsers(project.key);

    }))
}

export async function getCreatemeta (){
    
    const res = await requestJira(`/rest/api/2/issue/createmeta`);
    const data = await res.json();  
    
    return data;
}

const getUsers = async (key) => {

    let usersInfo = {
        projectName: key,
        datas: null
    }

    let url = '/rest/api/2/user/assignable/search?project=' + key;

    const res = await requestJira(url);

    const data = await res.json();

    usersInfo.datas = data;


    return usersInfo;
}

const getSprint = async () => {

    // let usersInfo = {
    //     projectName: key,
    //     datas: null
    // }

    let url = '/rest/agile/1.0/board/7/sprint';

    const res = await requestJira(url);

    const data = await res.json();

    console.log(data);
    // usersInfo.datas = data;

    // return usersInfo;
}

const getDatasComments = async (key) => {
    
    let status = 404;

    let projectInfo = {
        projectName: key,
        datas: []
    }
    
    let i = 1;

    while (true) {
        
        let url = '/rest/api/3/issue/' + key + '-' + i + '/comment';
    
        const res = await requestJira(url);
        const data = await res.json();


        if(res.status == status) {
            break;
        }

        let info = {
            projectKey: key + '-' + i,
            datas: data
        }
        
        projectInfo.datas.push(info);
        
        i++;
    }

    return projectInfo;
}

export default requestsToJira;