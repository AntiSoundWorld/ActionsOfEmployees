export async function requestsToBitBucket(basicToken) {

    const listOfWorkspacesName = await getBitBukcetWorkspaces(basicToken);
    const listOfRepositoriesName = await getListOfRepositories(listOfWorkspacesName, basicToken);

    const infoBitBucket = {
 
        repositoryCommits : await getRepositoryCommits(listOfRepositoriesName, basicToken),
        repositoryPullRequests: await getRepositoryPullRequests(listOfRepositoriesName, basicToken)
    }

    return infoBitBucket;
}

const getBitBukcetWorkspaces = async (basicToken) => {
    
    let listOfWorkspacesName = [];

    let url = 'https://api.bitbucket.org/2.0/workspaces';
    
    const res = await fetch(url, {

        headers: {
            'Authorization': basicToken
        }

    });

    const data = await res.json();

    data.values.map(currentElement => {

        listOfWorkspacesName.push(currentElement.slug);

    });

    return listOfWorkspacesName
}

async function getListOfRepositories(listOfWorkspacesName, basicToken){
    
    let listOfRepositoriesName = [];

    const asyncRes = await Promise.all(listOfWorkspacesName.map(async (workspace) => {
        return getListOfNamesRepositories(workspace, basicToken);
    }))

    asyncRes.map(currentElement => {
       currentElement.map(repositoryName => {
        listOfRepositoriesName.push(repositoryName);
       });
    })

    return listOfRepositoriesName
}

async function getListOfNamesRepositories(workspace, basicToken) {


    let listOfNamesRepositories = [];

    let repositoryNames = [];
    
    let url = 'https://api.bitbucket.org/2.0/repositories/' + workspace;
    
    const res = await fetch(url, {
        headers: {
            'Authorization': basicToken
        }
    });
    
    const data = await res.json();

    data.values.map(currentElement => {
        listOfNamesRepositories.push({
                workspace: workspace,
                repositoryNames: currentElement.slug
            }
        );
    });

    return listOfNamesRepositories
}

async function getRepositoryCommits(listOfRepositoriesName, basicToken){
    let asyncRes2 = [];

    let asynRes = await Promise.all(listOfRepositoriesName.map(async (currentElement) => {
        let url = 'https://api.bitbucket.org/2.0/repositories/' + currentElement.workspace + '/' + currentElement.repositoryNames  + '/commits';
        
        const res = await fetch(url, {
            headers: {
                'Authorization': basicToken
            }
        });

        const data = await res.json();
        let length = data.values.length;

        if(data.values[length -1].rendered.message.raw == 'Initial commit'){  // remove first commit of git ignore
            data.values.pop(0);
        };

        let info = {
            workspace: currentElement.workspace,
            data: data
        }

        asyncRes2.push(info);

        return data;
    }));

    return asyncRes2;
}

async function getRepositoryPullRequests(listOfRepositoriesName, basicToken){
    let asyncRes2 = [];

    let asynRes = await Promise.all(listOfRepositoriesName.map(async (currentElement) => {
 
        let url = 'https://api.bitbucket.org/2.0/repositories/' + currentElement.workspace + '/' + currentElement.repositoryNames  + '/pullrequests';
        
        const res = await fetch(url, {
            headers: {
                'Authorization': basicToken
            }
        });

        const data = await res.json();

        let info = {
            workspace: currentElement.workspace,
            data: data
        }
        asyncRes2.push(info);
        return data;
    }));

    return asyncRes2;
}

export default requestsToBitBucket;