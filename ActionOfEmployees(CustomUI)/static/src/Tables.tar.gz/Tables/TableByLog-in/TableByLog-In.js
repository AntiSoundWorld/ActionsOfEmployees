import React from 'react';

import OAuth from '../../OAuth';

function TableByLogIn(props){
    return (
        <div>
            <img 
                src='https://upload.wikimedia.org/wikipedia/commons/f/fc/Bitbucket_Logo.png'
                size='xsmall'>
            </img>

            <OAuth setUserBasicToken={props.setUserBasicToken}/>
            
        </div>

    )
}

export default TableByLogIn;