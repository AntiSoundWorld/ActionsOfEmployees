import React from 'react';

import { BodyOfTable } from './TableByEpmployees/BodyOfTable'
import { HeadOfTable } from './TableByEpmployees/HeadOfTable'

export function InitializedMyTable(props){

    return (
        <table>
            <HeadOfTable />
                {props.macket.map(macket => (
                    <BodyOfTable macket={macket} />  
            ))}
        </table>
    )
}