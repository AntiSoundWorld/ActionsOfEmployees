import React from 'react';

export function BodyOfTable(props){
    
    return (
        <tr>
            <td>
                accountId={props.macket.accountId}
            </td>
            <td>
                    {props.macket.numOfComments}
            </td>
            <td>
                    {props.macket.numOfCommits}
            </td>
            <td>
                    {props.macket.numOfpullRequests}
            </td>
        </tr>
    ) 
}