import React from 'react';

export function HeadOfTable(){

    return(
        <tr>
            <th>
                name
            </th>
            <th>
                jira comments
            </th>
            <th>
               BitBucket Commits
            </th>
            <th>
                BitBucket PullRequests
            </th>
        </tr>
    );
}